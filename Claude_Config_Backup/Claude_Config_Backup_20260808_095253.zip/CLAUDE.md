## 搜索工具（多平台 + 统一资源池轮询 — 2026-08-08 新增，PERMANENT）

> ## ⚠️ 永久性指令 — DEFAULT-ON / PERMANENT / AUTO-EXTEND
>
> | 属性 | 值 |
> |------|---|
> | **存储位置** | `~/.claude/CLAUDE.md`（user-level 全局指令，所有会话自动加载） |
> | **MCP 实例存储** | `~/.claude.json` → `mcpServers`（user-level，`-s user`，除非手动 `claude mcp remove` 否则永不丢失） |
> | **生效范围** | 所有项目 / 所有会话 / 所有对话（全局生效，无需重复声明） |
> | **默认启用** | ✅ 是（每次启动 Claude 自动加载本章节 + 自动连接所有 user-level MCP） |
> | **自动扩展** | ✅ 是（用户新增 KEY 后，按"新 KEY 加入 SOP"追加到池尾，规则自动适用） |
> | **反失效保护** | ✅ 已生效（`~/.claude/CLAUDE.md` 文件不主动删改本章节；MCP 实例不主动 remove） |
> | **版本** | v2.1 — 2026-08-08 |
> | **下次复核日期** | 仅当用户主动说"修订资源池规则"时触发；否则永久生效 |

> **核心原则（2026-08-08 用户更正）**：**所有平台的 KEY 统一打散到一个全局资源池**，按顺序逐个调用；任意 KEY 失败（超时 / 401 / 429 / 5xx / 解析错误）即降级到池中下一个，**不区分平台**。已配置 **Tavily / EXA / Firecrawl**（Firecrawl 待补真实 KEY 后启用），全局生效（`-s user`）。

### 🌀 全局 KEY 资源池（统一轮询顺序）

> 池中每一项都是一个独立的"调用槽位"，不管它来自 Tavily / EXA 还是 Firecrawl，遇到异常就直接跳到下一项；走完最后一项回到第 1 项继续循环，最多重试 **3 轮**。

| 池序 | MCP 实例 | 平台 | KEY 标识 | 状态 | 调用工具 |
|------|---------|------|---------|------|---------|
| 1️⃣ | `tavily-1` | Tavily | KEY1（1BxP1v） | ✅ | `mcp__tavily-1__tavily_search` |
| 2️⃣ | `tavily-2` | Tavily | KEY2（1OR2KB） | ✅ | `mcp__tavily-2__tavily_search` |
| 3️⃣ | `tavily-3` | Tavily | KEY3（2NSI2k） | ✅ | `mcp__tavily-3__tavily_search` |
| 4️⃣ | `exa-1` | EXA | EXA-KEY | ✅ | `mcp__exa-1__web_search_exa` |
| 5️⃣ | `firecrawl-1` | Firecrawl | KEY1（待补） | ⏳ | `mcp__firecrawl-1__firecrawl_search` |
| 6️⃣ | `firecrawl-2` | Firecrawl | KEY2（待补） | ⏳ | `mcp__firecrawl-2__firecrawl_search` |
| 7️⃣ | `firecrawl-3` | Firecrawl | KEY3（待补） | ⏳ | `mcp__firecrawl-3__firecrawl_search` |

> 池序按用户添加顺序排列；新 KEY 加入时自动追加到池尾。当前池满配后包含 7 个槽位（3 Tavily + 1 EXA + 3 Firecrawl）。

### 🔁 统一轮询调用规则（强制 — 2026-08-08 用户更正后）

1. **入口**：所有"网络搜索 / 网页抓取"类需求，**必须**从池序 1️⃣（`tavily-1`）开始调用
2. **失败判定**（任意一项命中即视为失败，立即降级到下一项）：
   - 网络超时 / 连接中断
   - HTTP 401 / 403 / 429 / 5xx
   - 返回 JSON 解析失败或无 result 字段
   - 调用工具不存在 / MCP 实例未连接
3. **降级路径**：`1️⃣ → 2️⃣ → 3️⃣ → 4️⃣ → 5️⃣ → 6️⃣ → 7️⃣ → 1️⃣ ...`（用完最后一项回到第 1 项）
4. **轮数上限**：池内走完一轮仍全部失败 → 视为"整池不可用"，向用户报错；可再次发起请求时，从 1️⃣ 重新开始新一轮（最多 3 轮累计）
5. **跨平台参数适配**：降级到不同平台时，工具签名变化，按下表适配：

| 当前 → 降级 | 参数映射 |
|------------|---------|
| Tavily `tavily_search` → EXA `web_search_exa` | `query` → `query`；`max_results` → `numResults`；`topic` / `search_depth` 默认 |
| Tavily `tavily_search` → Firecrawl `firecrawl_search` | `query` → `query`；`max_results` → `limit` |
| EXA → Firecrawl（或反之） | `query` 通用；结果数量参数名分别为 `numResults` / `limit` |
| Tavily `tavily_extract/crawl/map` → EXA `get_contents` | URL 列表直接传 `urls` |

6. **结果归一化**：跨平台返回的结果字段名不同，统一映射为 `{title, url, content, score}` 四元组后再返回给用户

### ➕ 新 KEY 加入 SOP（自动扩展 — 永久生效）

> **触发条件**：用户新增任何平台的 KEY（Tavily / EXA / Firecrawl / 未来新平台）时，自动执行如下流程，**新 KEY 一律按池序追加到池尾**，不插入中间、不调整既有顺序。

| 步骤 | 命令模板（Windows / `-s user` 全局） | 命名规范 |
|------|-------------------------------------|---------|
| ① 添加 MCP 实例 | `claude mcp add-json {实例名} '{"command":"cmd","args":["/c","npx","-y","{包名}@latest"],"env":{"{KEY_ENV_NAME}":"{KEY}"}}' -s user` | `{平台}-{n}`（n 从 1 开始递增） |
| ② 更新资源池表格 | 在"全局 KEY 资源池"表格底部追加一行，池序 = 当前最大池序 + 1 | — |
| ③ 更新版本号 | 章节顶部"版本"字段 +0.0.1，记录新增日期 | v2.x |
| ④ 验证 | `npx -y {包名}@latest` 启动测试，确认 "running on stdio" | — |
| ⑤ 同步备份 | 按全局"三地备份规则"备份 `~/.claude/CLAUDE.md` + `~/.claude.json` 到 `F:\AI生成工具\AI技能备份\` | — |

**未来新平台举例**：若用户后续接入 `serper-1`、`brave-1`、`bing-1` 等，**直接追加到池尾**，无需修改既有规则。

### 📌 调用示例（伪代码）

```
用户: "搜索今日 AI 新闻"
↓
尝试 1️⃣ tavily-1.tavily_search("今日 AI 新闻")
  ├─ 成功 → 返回结果 ✅
  └─ 失败（超时/429/5xx）↓
尝试 2️⃣ tavily-2.tavily_search("今日 AI 新闻")
  ├─ 成功 → 返回结果 ✅
  └─ 失败↓
尝试 3️⃣ tavily-3.tavily_search("今日 AI 新闻")
  └─ 失败↓
尝试 4️⃣ exa-1.web_search_exa(query="今日 AI 新闻", numResults=5)
  ├─ 成功 → 归一化为 {title,url,content,score} 返回 ✅
  └─ 失败↓
尝试 5️⃣ firecrawl-1.firecrawl_search(...)   # 待 KEY
...循环往复，最多 3 轮
```

### 📚 平台特性建议（仅作选型参考，不影响池顺序）

- **Tavily**：中文支持最好、Result 质量高、含 `extract/crawl/map/research` 多种工具
- **EXA**：英文深度搜索 / 学术论文 / 神经搜索更强
- **Firecrawl**：整页抓取 / 反爬绕过 / 结构化提取强

### 📦 历史决策记录（永久存档）

- 2026-08-08 v1：最初按"平台内 KEY 轮询 + 跨平台兜底"实现 — **被用户否决**
- 2026-08-08 v2：**统一全局资源池**，任意 KEY 失败直接跳到池中下一个，不区分平台
- 2026-08-08 v2.1：**永久性 + 默认启用 + 自动扩展 + 反失效**加固（CLAUDE.md user-level 永久章节，MCP `-s user` 永久实例）

## ⚠️ 软件发布程序目录规范（强制规则 — 2026-07-26 新增，2026-08-02 修订：release/ → publish/）

> **强制规则**：任何项目发布程序（包括但不限于 dotnet publish 产物、Release zip 包、exe/dll 等可执行文件），**必须**遵守以下目录结构：
>
> ```
> <项目根目录>\
> ├── publish\                          ← 项目专用发布子目录（必备，唯一路径）
> │   ├── latest\                       ← 当前最新可发布的二进制（dotnet publish 产物）
> │   │   ├── Admin\   (或 Api\ / TrayApp\ / Web\ / Backend\ 等项目名)
> │   │   ├── Api\
> │   │   ├── TrayApp\
> │   │   └── UniApp\                   ← 移动端 APK/源码（如有）
> │   └── _archive\                     ← 历史发布 zip 包归档（命名：DormManage-v{版本}_{时间戳}.zip）
> │       ├── DormManage-v2.13.175_20260726_082544.zip
> │       └── DormManage-v2.13.177_20260726_101846.zip
> └── <其他源码目录>\
> ```

### 强制要求

| # | 项目 | 要求 |
|---|------|------|
| 1 | **必须创建 `publish/` 子目录** | 位于项目根目录（如 `E:\...\宿舍管理系统\publish\`），**禁止使用 `release/`** |
| 2 | **`latest/` 存放可部署文件** | `dotnet publish` 输出必须直接落到 `publish/latest/{项目名}/` 而非临时目录 |
| 3 | **`_archive/` 存放历史 zip 包** | 命名规则：`{项目名}-v{版本}_{YYYYMMDD_HHMMSS}.zip`（如 `DormManage-v2.13.177_20260726_101846.zip`） |
| 4 | **禁止污染根目录** | `*.zip`、`*.dll`、`*.exe` 等发布产物**禁止**直接放在项目根目录 |
| 5 | **禁止使用 `release/` 目录名** | 旧规范使用 `release/`，2026-08-02 起统一为 `publish/`，`release/` 已废弃 |
| 6 | **禁止使用通用目录名** | 不用 `publish-final/`、`dist/`、`out/`、`bin/`（`bin/` 是 dotnet 编译输出目录，不用于发布）作为发布根目录 |

### 适用范围

- ✅ 任何软件开发项目的 Release 构建
- ✅ 任何打包脚本（PowerShell、bash、Python）
- ✅ 任何持续集成（CI/CD）流水线的发布产物
- ❌ 不适用于开发期的 Debug 构建（仍在 `bin/Debug/`）
- ❌ 不适用于 dotnet 自身的 `bin/`/`obj/` 输出（项目级编译产物）

### 检查方法（自动化）

```powershell
# 验证项目根目录是否有 publish/ 子目录（而非 release/）
Test-Path "publish" -PathType Container

# 验证最新发布版本是否在 publish/latest/ 下
Test-Path "publish/latest" -PathType Container

# 验证 zip 包是否都归档在 publish/_archive/ 下
Get-ChildItem publish/_archive/*.zip
```

### 当前项目示范

> **JINGE 宿舍管理系统** 已于 2026-08-02 完成从 `release/` 到 `publish/` 的迁移：
> ```
> E:\AI工作目录\AI编程开发\JINGE开发\宿舍管理系统\publish\
> ├── latest\（Admin + Api + TrayApp + UniApp）
> └── _archive\（DormManage-v3.0.0.2-pda-fix-with-apk_20260802_062756.zip 等）
> ```

## 软件开发项目文档冲突检查与同步规则（必备原则）

> ⚠️ **强制规则（必备遵守原则）**：对所有软件开发项目的变更修改或新增需求/功能开发任务时，必须对任务的内容优先执行如下规则。

### 规则内容

对「开发方案」及「功能需求 / 原型设计 / 设计规范」的项目相关所有文档进行如下的冲突检查，并按如下内容 / 数据逻辑 / 计算方法等 进行更新或补充对应文档的相关描述。

### 具体要求

| # | 检查项 | 要求 |
|---|--------|------|
| 1 | **变更影响范围** | 检查所有受影响的文档（开发方案、功能需求、原型设计、设计规范）是否需要更新 |
| 2 | **数据逻辑一致性** | 字段定义、状态枚举、业务规则在所有文档中必须保持一致 |
| 3 | **计算方法一致性** | 费用计算、统计口径、公式推导在所有文档中必须保持一致 |
| 4 | **冲突解决** | 如发现冲突，按以下优先级处理：① 开发方案 > 功能需求 > 原型设计；② 最新的需求文档优先 |
| 5 | **文档同步** | 在代码开发前完成相关文档的更新或补充 |
| 6 | **版本号管理** | 新增/修改内容必须更新文档版本号，并在文档头标注变更日期 |

### ⚠️ 原型功能完整性强制规则（P0，最高优先级）

> **针对 2026-07 用户反馈"自动导出 Excel 按钮无响应""主菜单列表底部无分页器"等典型问题新增：** 任何功能必须在 HTML 原型存在的前提下 1:1 真实实现，禁止使用 placeholder/alert/演示版占位。

#### 强制要求

| # | 项目 | 要求 |
|---|------|------|
| 1 | **功能 1:1 实现** | 每个 HTML 原型页面中的按钮、表格、弹窗、表单、校验、跳转、API 调用、分页器都必须**真实实现**，不允许仅写 UI 不接 API、不允许 `alert('原型演示...')` 占位 |
| 2 | **占位符清零** | 全局 `grep -rn "alert('原型演示\|placeholder\|TODO\|待实现\|原型演示：\|演示："` 必须 = 0 命中；命中即 P0 必修 |
| 3 | **按钮/操作可用性** | 每个 `btn` / `<a>` 元素都必须有可执行的 `onclick` / `href` / `asp-page-handler` / API endpoint，404 / 500 / 无响应即视为严重缺陷 |
| 4 | **业务规则硬约束** | 原型中展示的所有字段、状态机、校验逻辑（如 status=1/2 不可覆盖、读数必须 ≥ 上月）必须**真实实现**到后端 Service 层，文档与代码一致 |
| 5 | **数据真实落库** | 所有"新增/编辑/删除/导入/导出"操作必须落到真实表，不能 `TempData` 提示后跳走即结束 |
| 6 | **变更触发对比** | 任何功能修改、新页面开发、CRUD 调整前，**必须先读 HTML 原型**（`00-方案文档/04-HTML原型/`）并与当前代码对比，输出差距清单后方可实施 |
| 7 | **无法 1:1 时主动提示** | 如因技术/资源限制不能 100% 实现某项功能，**必须在对话中显式告知用户**哪些功能已完成 / 哪些降级实现 / 哪些待后续工作；不得隐藏或假装完成 |
| 8 | **列表分页器 100% 原型对齐** | 所有列表页（人员清单/宿舍登记/宿舍档案/抄表记录/账单/费用标准/系统设置用户管理等）底部**必须**使用统一分页组件：`« 1 2 3 … 65 »` 智能截断 + 每页 [10/20/50/100] dropdown + 统计 `共 N 条 · 第 X-Y 条 · 共 Z 页`。禁止用 Bootstrap 默认 `« ‹ 1 2 3 › »` 简单按钮或 `共 N 条记录，第 X / Y 页` 文案。实现方式：使用 `DormManage.Admin/Pages/Shared/_PaginationPartial.cshtml` 共享分页组件，`PaginationModel` 参数为 `(PageIndex, PageSize, TotalCount)`，URL 参数自动从 `Context.Request.QueryString` 提取并保留。 |

### UI 风格一致性要求

| 要素 | 规范 |
|------|------|
| **页头风格** | 所有列表型页面必须使用统一的页头格式（图标 + 标题 + 总数 + 操作按钮） |
| **筛选条件区域** | 必须使用 `flex-nowrap` 一行排列，根据屏幕宽度自适应调整字段宽度 |
| **列表序号** | 第一列必须为"序号"，按 `(PageIndex-1)*PageSize+行号` 计算，跨页连续编号 |
| **页尾分页** | 所有列表页尾分页样式完全一致（统计信息 + 分页器） |
| **响应式** | 768px 以下筛选条件自动改为 2 列布局 |
| **查询/重置按钮** | 高度固定 38px，宽度固定 100px，风格完全一致（圆角 6px，字体 14px，图标 14px，padding 0 16px，flex 居中） |
| **设计规范** | 参照 `00-方案文档/35-列表页面统一UI设计规范-v2.11.4.md` |
| **筛选条件持久化** | 所有列表页筛选条件值优先写入 localStorage（用户退出登录时若未勾选"存储筛选条件"则清除）；若勾选"存储筛选条件"则在个人中心写入数据库缓存表（SysUserFilterCache），下次登录自动加载至对应模块筛选区；提供"清除"按钮一键清空所有模块缓存值 |
| **双 UI 职责划分** | 托盘系统配置窗口（SettingsForm）仅保留核心服务端参数（PDA/Web 端口、数据库、图片路径、服务启停、保存），无权限控制；Web 端系统设置承载全部功能（用户角色/备份恢复/系统集成/筛选缓存等），受角色权限管控 |

### 适用范围

- ✅ 新增功能模块
- ✅ 修改现有功能
- ✅ 重构模块
- ✅ 数据库表结构变更
- ✅ API 端点变更
- ✅ 业务流程变更
- ✅ UI 风格调整

### 不适用范围

- ❌ 文档本身的格式优化（拼写、错别字等）
- ❌ 注释或日志信息的修改
- ❌ 不影响业务逻辑的代码微调

## Skill技能安装规范
安装新技能时，必须根据技能SKILL.md中的功能描述，将技能安装到对应分类名称的子目录下：

### 分类目录结构
| 分类目录 | 说明 |
|---------|------|
| 01-AI工作流 | AI代理、自动化工作流、多智能体协作相关技能 |
| 02-数据分析 | 数据处理、Pandas、SQL、可视化分析相关技能 |
| 03-A股量化 | 股票数据分析、量化交易、金融建模相关技能 |
| 04-VibeCoding | 前端开发、UI设计、移动端开发相关技能 |
| 05-内容创作 | 文案写作、内容营销、社交媒体相关技能 |
| 06-职场效率 | 会议记录、演示文稿、OKR管理相关技能 |
| 07-研究调研 | 深度研究、竞品分析、市场调研相关技能 |
| 08-基础设施 | Docker、Kubernetes、CI/CD相关技能 |
| 09-开发框架 | 后端框架、API设计、数据库相关技能 |
| 10-知识库 | 文档管理、RAG、知识图谱相关技能 |
| 11-安全防护 | 安全扫描、漏洞检测、合规相关技能 |
| 12-Claude原厂 | Claude官方提供的原生技能 |

### 安装规则
- 默认安装路径：`~/.claude/skills/{分类目录}/{技能名称}/`
- 安装前必须读取技能SKILL.md文件，根据功能描述确定正确的分类
- 如果技能涉及多个分类，根据其主要功能选择最合适的分类
- 安装后更新skills-lock.json记录

## Skill技能 & Claude 数据备份规范

所有操作（技能升级/新增/修改；Claude 配置数据；迁移归档）完成后，必须同步执行以下三地备份：

### 三地备份规则（统一目录 + 文件名前缀区分）
| # | 备份位置 | 内容 | 命名规则 |
|---|---------|------|---------|
| ① | **本地统一备份** | `F:\AI生成工具\AI技能备份\` | 按内容类型用前缀区分（见下表） |
| ② | **GitHub线上备份** | `git@github.com:mecallsun/skills-backup.git` | commit+push（按技能提交） |

> 自 2026-07-03 起，原 ①「本地 Claude 备份」路径 `~/.claude/backups/` 已统一到 `F:\AI生成工具\AI技能备份\`，并改用压缩包命名。Claude Code 自身的 `.claude.json.backup.*` 文件仍由其内部写入 `~/.claude\backups\`，不受本规范约束。

### ① 本地备份 — 类型与文件名前缀

| 类型 | 数据源 | 前缀 | 用途 |
|------|--------|-----|------|
| **Skills 技能完整备份** | `C:\Users\Mecall\.claude\skills\*` | `Claude_Skills_Backup_` | 全量 12 个分类目录打包，便于跨机恢复 |
| **Config Claude 配置备份** | `D:\.claude\*`（junction 后唯一真实目录） | `Claude_Config_Backup_` | history.jsonl、projects、sessions 等运行时数据 |
| **Migration 迁移脚本归档** | `C:\claude_migration_tmp\*` | `Claude_Migration_Backup_` | 迁移相关脚本与日志归档 |

- **文件命名格式**：`Claude_<类型>_Backup_YYYYMMDD_HHMMSS.zip`
  - 类型 = `Skills` / `Config` / `Migration`
  - YYYY = 4 位年份
  - MM = 2 位月份（01-12）
  - DD = 2 位日期（01-31）
  - HH = 2 位小时（24 小时制，00-23）
  - MM = 2 位分钟（00-59）
  - SS = 2 位秒（00-59）
- **路径规范**：`F:\AI生成工具\AI技能备份\Claude_<类型>_Backup_YYYYMMDD_HHMMSS.zip`
- **Latest 指向**：每种类型都要同步复制为 `Claude_<类型>_Backup_Latest.zip` 并解压到 `Claude_<类型>_Backup_Latest\` 目录（便于快速浏览）

### 执行命令参考
```powershell
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$dest = "F:\AI生成工具\AI技能备份"

# 1) 技能完整备份
Compress-Archive -Path "C:\Users\Mecall\.claude\skills\*" `
  -DestinationPath "$dest\Claude_Skills_Backup_$ts.zip" `
  -CompressionLevel Optimal

# 2) Claude 配置备份（备份真实目录 D:\.claude，junction 后与 C: 内容一致）
Compress-Archive -Path "D:\.claude\*" `
  -DestinationPath "$dest\Claude_Config_Backup_$ts.zip" `
  -CompressionLevel Optimal

# 3) 迁移脚本归档（如有迁移相关内容）
if (Test-Path "C:\claude_migration_tmp") {
    Compress-Archive -Path "C:\claude_migration_tmp\*" `
      -DestinationPath "$dest\Claude_Migration_Backup_$ts.zip" `
      -CompressionLevel Optimal
}

# 4) 更新 Latest 指向（每种类型各做一次）
foreach ($type in @("Skills","Config","Migration")) {
    $latestZip = "$dest\Claude_${type}_Backup_Latest.zip"
    $latestDir = "$dest\Claude_${type}_Backup_Latest"
    $srcZip = "$dest\Claude_${type}_Backup_$ts.zip"
    if (Test-Path $srcZip) {
        Copy-Item $srcZip $latestZip -Force
        Remove-Item $latestDir -Recurse -Force -ErrorAction SilentlyContinue
        Expand-Archive $latestZip -DestinationPath "$latestDir\" -Force
    }
}
```

### 历史备份命名样例
```
# 旧规范（迁移前 ~/.claude/backups/ 时代的 Mecall-ITReport 目录）
Mecall-ITReport-v2.0-20260627/
Mecall-ITReport-v2.4-20260628/

# 已统一到 F:\AI生成工具\AI技能备份\ 的压缩包历史
Claude_Skills_Backup_20260529_230905.zip   (2026-05-29 23:09:05)
Claude_Skills_Backup_20260530_201227.zip   (2026-05-30 20:12:27)
Claude_Skills_Backup_20260627_153428.zip   (2026-06-27 15:34:28)
Claude_Skills_Backup_20260628_034243.zip   (2026-06-28 03:42:43)
Claude_Skills_Backup_20260703_011826.zip   (2026-07-03 01:18:26)  ← 新规范生效

# 本次会话创建的其他类型备份
Claude_Config_Backup_20260703_011826.zip   (2026-07-03 01:18:26, 378MB→156MB)
Claude_Migration_Backup_20260703_011826.zip (2026-07-03 01:18:26)
```
```
## ⚠️ 大需求任务处理机制（按 AI 模型参数分阶段执行）— 2026-08-08 新增

> **强制规则**：处理大需求/复杂任务时，必须先根据当前 AI 模型参数（context window、推理能力、回复长度限制）评估任务规模，然后按"分阶段、分步骤、有顺序"的方式执行，每个阶段完成后进行结果梳理/整理/组织，最后统一整合。

### 核心流程（4 阶段）

| 阶段 | 内容 | 产出 |
|------|------|------|
| **① 任务分析** | 模型参数评估（context length / 推理能力 / 回复长度限制）→ 拆解任务 + 识别依赖 + 风险点 | 任务分解清单（TaskCreate） |
| **② 分步执行** | 按依赖顺序逐步实现（每个 Task 独立完成 + 验证） | 每个步骤的代码改动 + 编译验证 |
| **③ 阶段梳理** | 每个阶段完成后整理（每阶段必出阶段性结果报告） | 检查点报告（代码 + 文档 + 风险） |
| **④ 整合发布** | 编译 + 测试 + 文档同步 + zip 包 | 最终交付（按 v3.0.5.0 发布规则） |

### 强制要求

| # | 项目 | 要求 |
|---|------|------|
| 1 | **必须先 TaskCreate** | 任何超过 3 步骤的大任务必须先用 TaskCreate 创建任务列表，然后逐个 in_progress / completed |
| 2 | **每个 Task 必须有清晰边界** | 单 Task 改动 ≤ 5 个文件，且编译通过 |
| 3 | **必须按模型参数调整策略** | Opus 4.8 (1M context) → 可一次性加载大量源码分析；小型模型 → 必须先精简再分步 |
| 4 | **每个阶段必出报告** | 完成阶段后必须总结：① 改了哪些文件 ② 验证了什么 ③ 下一步做什么 |
| 5 | **必须 skill 调用规范** | 编译用 `dotnet build`、发布用 `dotnet publish`、代码搜索用 Grep、文档编辑用 Edit/Write、Web 验证用 curl + EventLog |
| 6 | **必须遵守已有强制规则** | v3.0.7.15 op-btn 规范、v3.0.7.22 @section Styles 唯一、v3.0.7.15+ 原型功能完整性、文档冲突检查 + 同步、原型 1:1 实现 |

### 适用范围

- ✅ 大需求（>10 个文件改动 或 >500 行代码）
- ✅ 多模块协同（跨 Shared + Admin + Api + TrayApp）
- ✅ 复杂 BUG 修复（需要分析多文件链路）
- ✅ 新功能实装（含原型 + 程序 + 文档 + 发布包）
- ❌ 简单单文件修改（直接改即可）
- ❌ 简单问答（直接回答即可）

### 模型参数适配表

| 模型 | Context | 策略 |
|------|---------|------|
| Opus 4.8 (1M) | 1M tokens | 大规模源码分析 + 多文件同时改 + 一次性综合报告 |
| Sonnet 4.5 (200K) | 200K tokens | 分批分析，每批 ≤ 50 个文件，分步执行 |
| Haiku 4.5 (200K) | 200K tokens | 严格分步，每次 ≤ 20 个文件，必须先 grep 验证 |
